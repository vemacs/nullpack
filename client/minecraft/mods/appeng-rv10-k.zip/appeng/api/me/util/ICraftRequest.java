package appeng.api.me.util;

public interface ICraftRequest {

}
