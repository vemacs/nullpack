package appeng.api.me.tiles;

/**
 * Cables will connect, but signal will not propagate. ( IFulllyOptionalMETile disconnects )
 */
public interface IOptionalMETile {
	
	public boolean isEnabled();
	
}
