package appeng.api;

public interface ILocateableRegistry {

	public abstract Object findLocateableBySerial(long ser);

}